﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hotel.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageLogin.xaml
    /// </summary>
    public partial class PageLogin : Page
    {
        private HotelPraktikaEntities _db;
        public PageLogin()
        {
            InitializeComponent();
            _db = new HotelPraktikaEntities();
        }

        private void Auth_Click(object sender, RoutedEventArgs e)
        {
            var userObj = OdbConnectHelper.entObj.Пользователи.FirstOrDefault(x => x.Логин == Login.Text && x.Пароль == Psswrd.Password);
            if (userObj != null)
            {
                FrameApp.frmObj.Navigate(new PageMenu());
            }
            else MessageBox.Show("Неправильный логин или пароль");
        }
    }
}
