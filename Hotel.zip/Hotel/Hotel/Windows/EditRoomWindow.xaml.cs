﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Hotel.Windows;

namespace Hotel.Windows
{
    public partial class EditRoomWindow : Window
    {
        private Номер _room;

        public EditRoomWindow(Номер room)
        {
            InitializeComponent();
            _room = room;
            LoadData();
        }

        private void LoadData()
        {
           // txtNumber.Text = _room.Номер1;
            txtFloor.Text = _room.Этаж;
            cmbCategory.ItemsSource = new[] { "Стандарт", "Люкс" };
            cmbCategory.SelectedItem = _room.Категория;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            _room.Номер1 = Convert.ToInt32(txtNumber.Text);
            _room.Этаж = txtFloor.Text;
            _room.Категория = cmbCategory.SelectedItem.ToString();
            OdbConnectHelper.entObj.SaveChanges();
            DialogResult = true;
        }
    }
}
