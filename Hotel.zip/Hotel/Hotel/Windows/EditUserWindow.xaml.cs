﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hotel.Windows
{
    public partial class EditUserWindow : Window
    {
        private Пользователи _user;

        public EditUserWindow(Пользователи user)
        {
            InitializeComponent();
            _user = user;
            LoadData();
        }

        private void LoadData()
        {
            txtLogin.Text = _user.Логин;
            txtPassword.Password = _user.Пароль;
            cmbRole.ItemsSource = new[] { "Администратор", "Менеджер", "Гость" };
            cmbRole.SelectedItem = _user.Роль;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            _user.Логин = txtLogin.Text;
            _user.Пароль = txtPassword.Password;
            _user.Роль = cmbRole.SelectedItem.ToString();
            OdbConnectHelper.entObj.SaveChanges();
            DialogResult = true;
        }
    }
}
