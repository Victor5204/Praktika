﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Hotel.Windows;

namespace Hotel.Windows
{
    public partial class EditGuestWindow : Window
    {
        private Постояльцы _guest;

        public EditGuestWindow(Постояльцы guest)
        {
            InitializeComponent();
            _guest = guest;
            LoadData();
        }

        private void LoadData()
        {
            txtFullName.Text = _guest.ФИО;
           // txtPhone.Text = _guest.Номер;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            _guest.ФИО = txtFullName.Text;
            _guest.Номер = Convert.ToInt32(txtPhone.Text);
            OdbConnectHelper.entObj.SaveChanges();
            DialogResult = true;
        }
    }
}
