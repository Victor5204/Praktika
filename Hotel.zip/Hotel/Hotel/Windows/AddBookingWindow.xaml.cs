﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Hotel.Pages;
using Hotel.Windows;


namespace Hotel.Windows
{
    public partial class AddBookingWindow : Window
    {
        public AddBookingWindow()
        {
            InitializeComponent();
            cmbGuest.ItemsSource = OdbConnectHelper.entObj.Постояльцы.ToList();
            cmbRoom.ItemsSource = OdbConnectHelper.entObj.Номер.ToList();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var booking = new Бронирование
            {
                Постоялец = (int)cmbGuest.SelectedValue,
                Номер = (int)cmbRoom.SelectedValue,
                Сумма = txtAmount.Text
            };

            OdbConnectHelper.entObj.Бронирование.Add(booking);
            OdbConnectHelper.entObj.SaveChanges();
            DialogResult = true;
        }
    }
}
