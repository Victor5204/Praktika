﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Hotel.Windows;

namespace Hotel.Windows
{
    public partial class AddCleaningWindow : Window
    {
        public AddCleaningWindow()
        {
            InitializeComponent();
            cmbRoom.ItemsSource = OdbConnectHelper.entObj.Номер.ToList();
            cmbEmployee.ItemsSource = OdbConnectHelper.entObj.Пользователи
                .Where(u => u.Роль == "Менеджер" || u.Роль == "Администратор")
                .ToList();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var cleaning = new Уборка
            {
                Номер = (int)cmbRoom.SelectedValue,
                Сотрудник = (int)cmbEmployee.SelectedValue
            };

            OdbConnectHelper.entObj.Уборка.Add(cleaning);
            OdbConnectHelper.entObj.SaveChanges();
            DialogResult = true;
        }
    }
}
