﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Hotel.Windows;

namespace Hotel.Windows
{
    public partial class EditCleaningWindow : Window
    {
        private Уборка _cleaning;

        public EditCleaningWindow(Уборка cleaning)
        {
            InitializeComponent();
            _cleaning = cleaning;
            LoadData();
        }

        private void LoadData()
        {
            cmbRoom.ItemsSource = OdbConnectHelper.entObj.Номер.ToList();
            cmbEmployee.ItemsSource = OdbConnectHelper.entObj.Пользователи
                .Where(u => u.Роль == "Менеджер" || u.Роль == "Администратор")
                .ToList();

            cmbRoom.SelectedValue = _cleaning.Номер;
            cmbEmployee.SelectedValue = _cleaning.Сотрудник;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            _cleaning.Номер = (int)cmbRoom.SelectedValue;
            _cleaning.Сотрудник = (int)cmbEmployee.SelectedValue;
            OdbConnectHelper.entObj.SaveChanges();
            DialogResult = true;
        }
    }
}
