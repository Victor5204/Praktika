﻿using Hotel.Data;
using Hotel.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hotel.Pages
{
    public partial class UsersPage : Page
    {
        public UsersPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            dgUsers.ItemsSource = OdbConnectHelper.entObj.Пользователи.ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            var addUserWindow = new AddUserWindow();
            if (addUserWindow.ShowDialog() == true)
            {
                LoadData(); // Обновляем данные после добавления
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedUser = dgUsers.SelectedItem as Пользователи;
            if (selectedUser != null)
            {
                var editUserWindow = new EditUserWindow(selectedUser);
                if (editUserWindow.ShowDialog() == true)
                {
                    LoadData(); // Обновляем данные после редактирования
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для редактирования.");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedUser = dgUsers.SelectedItem as Пользователи;
            if (selectedUser != null)
            {
                OdbConnectHelper.entObj.Пользователи.Remove(selectedUser);
                OdbConnectHelper.entObj.SaveChanges();
                LoadData(); // Обновляем данные после удаления
            }
            else
            {
                MessageBox.Show("Выберите пользователя для удаления.");
            }
        }
    }
}
