﻿using Hotel.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Hotel.Windows;

namespace Hotel.Pages
{
    public partial class RoomsPage : Page
    {
        public RoomsPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            dgRooms.ItemsSource = OdbConnectHelper.entObj.Номер.ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            var addRoomWindow = new AddRoomWindow();
            if (addRoomWindow.ShowDialog() == true)
            {
                LoadData(); // Обновляем данные после добавления
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedRoom = dgRooms.SelectedItem as Номер;
            if (selectedRoom != null)
            {
                var editRoomWindow = new EditRoomWindow(selectedRoom);
                if (editRoomWindow.ShowDialog() == true)
                {
                    LoadData(); // Обновляем данные после редактирования
                }
            }
            else
            {
                MessageBox.Show("Выберите номер для редактирования.");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedRoom = dgRooms.SelectedItem as Номер;
            if (selectedRoom != null)
            {
                OdbConnectHelper.entObj.Номер.Remove(selectedRoom);
                OdbConnectHelper.entObj.SaveChanges();
                LoadData(); // Обновляем данные после удаления
            }
            else
            {
                MessageBox.Show("Выберите номер для удаления.");
            }
        }
    }
}
