﻿using Hotel.Data;
using Hotel.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hotel.Pages
{
    public partial class BookingPage : Page
    {
        public BookingPage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            dgBooking.ItemsSource = OdbConnectHelper.entObj.Бронирование.ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Логика добавления бронирования
            var addBookingWindow = new AddBookingWindow();
            if (addBookingWindow.ShowDialog() == true)
            {
                LoadData(); // Обновляем данные после добавления
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedBooking = dgBooking.SelectedItem as Бронирование;
            if (selectedBooking != null)
            {
                var editBookingWindow = new EditBookingWindow(selectedBooking);
                if (editBookingWindow.ShowDialog() == true)
                {
                    LoadData(); // Обновляем данные после редактирования
                }
            }
            else
            {
                MessageBox.Show("Выберите бронирование для редактирования.");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var selectedBooking = dgBooking.SelectedItem as Бронирование;
            if (selectedBooking != null)
            {
                OdbConnectHelper.entObj.Бронирование.Remove(selectedBooking);
                OdbConnectHelper.entObj.SaveChanges();
                LoadData(); // Обновляем данные после удаления
            }
            else
            {
                MessageBox.Show("Выберите бронирование для удаления.");
            }
        }
    }
}
