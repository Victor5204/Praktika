﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hotel.Pages
{
    public partial class MainMenuPage : Page
    {
        private string _role;

        public MainMenuPage(string role)
        {
            InitializeComponent();
            _role = role;
            CheckAccess();
            MessageBox.Show($"Текущая роль: {_role}"); // Для отладки
        }

        private void CheckAccess()
        {
            // Проверка с учетом регистра
            btnCleaning.Visibility =
                (_role.Equals("Администратор", StringComparison.OrdinalIgnoreCase) ||
                 _role.Equals("Менеджер", StringComparison.OrdinalIgnoreCase))
                ? Visibility.Visible
                : Visibility.Collapsed;

            btnBooking.Visibility =
                (!_role.Equals("Гость", StringComparison.OrdinalIgnoreCase))
                ? Visibility.Visible
                : Visibility.Collapsed;

            btnUsers.Visibility =
                (_role.Equals("Администратор", StringComparison.OrdinalIgnoreCase))
                ? Visibility.Visible
                : Visibility.Collapsed;

            btnGuests.Visibility =
                (_role.Equals("Администратор", StringComparison.OrdinalIgnoreCase) ||
                 _role.Equals("Менеджер", StringComparison.OrdinalIgnoreCase))
                ? Visibility.Visible
                : Visibility.Collapsed;
        }

        private void btnCleaning_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new CleaningPage());
        }

        private void btnBooking_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new BookingPage());
        }

        private void btnUsers_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new UsersPage());
        }

        private void btnRooms_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RoomsPage());
        }

        private void btnGuests_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new GuestsPage());
        }
    }
}
